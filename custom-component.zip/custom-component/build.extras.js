// This is only to make sure that the module builder exports the demo bot template.
// If you don't include bot templates with your module, this file can be excluded.
module.exports = {
  copyFiles: ['src/bot-templates/**']
}
