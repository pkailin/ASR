import React from 'react'

export default class MyModule extends React.Component {
  // This would be the main interface of your bot on the module page.
  // Your module still needs to export an empty component if you don't use any.
  render() {
    return null
  }
}
