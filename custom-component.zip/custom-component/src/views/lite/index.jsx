import React from 'react'

// This is an example on how to replace the webchat composer (the typing zone)
export { Composer } from './components/Composer'

